// Empty file to generate docs

/** api: example[pdokviewer]
 *  PDOK
 *  ----
 *  Demonstrates Viewer developed for the Dutch National SDI: PDOK (Publieke Dienstverlening Op de Kaart).
 */

