// Empty file to generate docs

/** api: example[workshopnl]
 *  Heron Workshop (Dutch Grid)
 *  ---------------------------
 *  Answers for Heron Workshop exercises (Dutch Maps/Grid).
 */

