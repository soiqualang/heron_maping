Sources of images:

http://www.famfamfam.com/lab/icons/silk/
http://projects.opengeo.org/geosilk
http://www.iconarchive.com/
http://openiconlibrary.sourceforge.net (star.png renamed from emblem-special.png)

