These are some tests to test your CGI service. For example when using another programming language
than Python like Java or PHP for the CGI programs.
